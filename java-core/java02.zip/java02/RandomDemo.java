import java.util.Random;
import java.util.Scanner;
public class RandomDemo{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		Random rd = new Random();
		//1.随机产生一个整数
		int number = rd.nextInt();
		System.out.println(number);
		//需要：随机产生一个4位整数的会员号 1000~9999
		//2.1 0~9
		int number2= rd.nextInt(10);
		System.out.println(number2);

		//2.2 1~9
		int number3 = rd.nextInt(9)	;
		System.out.println(number3);

		//随机产生会员号:随机产生一个4位整数的会员号 1000~9999
		int memberNumber = rd.nextInt(9000)+1000;
		System.out.println("随机会员号为："+memberNumber);	

		//测试int表示的最大整数
		//System.out.println(Integer.MAX_VALUE);


		System.out.println("请输入一个四位整数！");
		int a = input.nextInt();
		if(a/1000>0&&a/10000==0){
			System.out.println(a+"是一个四位整数！！");
		}






	}
}
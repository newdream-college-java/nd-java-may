public class Demo05{
	public static void main(String[] args){
		//int a = 23;
		//int b = (a++)+(--a)+(a--)-(++a);
		//System.out.println(b);


		int a = 100;
		int mc =3;
		int sum = 0;

		int i =0;
		while(sum<a){
			if(sum<a){				//i =2 ;
				sum=sum+mc;
			}
			i++;
		}
		System.out.println(i+"次");
	}
}
public class WhileDemo01{
	public static void main(String[] args){
		int i=0;
		while(i<1000){
			//循环体
			System.out.println((i+1) +"---我爱你");	
			i=i+1;
		}
	}
}
public class Demo06{
	public static void main(String[] args){
		int sum = 0;

		int i =1;
		while(i<101){
			//sum=sum+i;
			sum+=i;
			i++;
		}
		System.out.println("和为："+sum);//这句代码只要执行一次，所有不要放到while中



	}
}
/*
练习1：使用循环输出100句“java02是最棒的”，然后再输出200句“以后各个都是高富帅，白富美！”

*/
public class WhileDemo02{
	public static void main(String[] args){
		int i=2;
		while(i<=200){
			System.out.println("java02是最棒的");
			i=i+2;
		}

		int j =1;
		while(j<=200){
			System.out.println("以后各个都是高富帅，白富美！");
			j=j+1;
		}
	}
}
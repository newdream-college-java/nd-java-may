/*
5)循环问国贤是否达标：如果回答：“no”
	继续问：“国贤是否达标” 如果回答：“no”
	继续问：“国贤是否达标” 如果回答：“no”
	...
	继续问：“国贤是否达标” 如果回答：“yes"
	停止循环，输出 国贤还是不错的！！！

要重复做
//1.问
//2,答
 

*/

import java.util.Scanner;
public class Demo07{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		//1.问
		System.out.println("国贤是否达标:");
		//2.答
		String answer = input.next();
		while(answer.equals("no")){
			//1.问
			System.out.println("国贤是否达标");
			//2.答
			answer = input.next();
		}
		System.out.println("国贤还是不错的！！！");


	}
}
public class WhileDemo04{
	public static void main(String[] args){
		int a=1;
		int b=1;
		int c ;
		System.out.print(a+"\t");
		System.out.print(b+"\t");

		int i=3;
		while(i<=20){
			c = a+b;				//第i个数
			System.out.print(c+"\t");//2
			a=b;
			b=c;

			i=i+1;
		}

	}
}
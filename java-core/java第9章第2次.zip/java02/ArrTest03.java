/*有一个数列：8，4，2，1，23，344，12
循环输出数列的值
求数列中所有数值的和
猜数游戏：从键盘中任意输入一个数据，判断数列中是否包含此数 


练习：定义数组保存1~10中所有的偶数，并求和输出，随机生成一个1~100之间的整数
判断这个随机数是不是在这个数组中。
*/
import java.util.*;
public class ArrTest03{
	public static void main(String[] args){
		Scanner input =new Scanner(System.in);
		int[] arr = {8,4,2,1,23,344,12};
		int sum = 0;
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"\t");
			sum+=arr[i];
		}
		System.out.println("\n数组所有值的和为："+sum);
		//提示
		System.out.print("请输入与你要查找的整数：");
		int number = input.nextInt();
		//查找问题：标记法
		boolean flag = false;//假设没有在数组中
		for(int i=0;i<arr.length;i++){
			if(number==arr[i]){
				//找到了
				System.out.println(number+"在数组的下标为"+i+"的位置");
				flag = true;
				//停止查找
				break;
			}
		}

		/*这里的代码用上面的循环替代了
		if(number==arr[0]){
			//找到了
			//停止查找
		}
		if(number==arr[1]){
			//找到了
			//停止查找
		}
		*/
		if(!flag){//flag ==false
			System.out.println(number+"不在数组中");
		}

	}
}
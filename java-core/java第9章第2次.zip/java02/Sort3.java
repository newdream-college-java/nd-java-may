/*

*/
public class Sort3{
	public static void main(String[] args){
		int[] arr = {9,6,8,5,7};
		int tmp ;
		for(int i=1;i<arr.length;i++){//i表示轮数	
			for(int j=i;j>0;j--){
				if(arr[j]>arr[j-1]){
					//交换;
					tmp = arr[j];
					arr[j] = arr[j-1];
					arr[j-1]=tmp;
				}else{

					break;
				}
			}
		}
		//输出数组的结果
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"\t");
		}



	}
}
public class ChoiceSort{
	public static void main(String[] args){
		int[] arr = {9,6,8,5,7};
		int k = 1; //选择的下标后面的数据的下标
		int m = 0;//选择的下标
		int tmp = 0;//交换的中间变量
		for(int i=1;i<arr.length;i++){//比较的轮数
			//K=1;
			//A[m]与a[1],a[2]…a[4]进行比较
			for(int j=k;j<arr.length;j++){//每轮比较的次数
		     	if(arr[m]<arr[j]){//交换
		     		tmp = arr[m];
		     		arr[m] = arr[j];
		     		arr[j] = tmp;
		     	}   
			}
			k++;
			m++;
		}
		//输出数组的值
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"\t");
		}


		

	}
}
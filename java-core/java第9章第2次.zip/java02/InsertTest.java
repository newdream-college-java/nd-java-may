/*
有一组学员的成绩{99，82，85，60， 63}，将它们按升序排列。
要增加一个学员的成绩，将它插入成绩序列，并保持升序。


*/
import java.util.*;
public class InsertTest{
	public static void main(String[] args){
		int[] arr = {99,82,85,60,63,0};//多开一个空间
		//升序排序
		Arrays.sort(arr);
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"\t");
		}
		//int[] arr = {0,60,63,82,85,99}
		Scanner input = new Scanner(System.in);
		System.out.print("\n请输入这个同学的成绩：");
		int score = input.nextInt();//77  100  -1
		//方式一：先插入数组的arr[0],然后移动位置。
		//方式二：先找到插入的位置，移动元素，插入新的分数。
		//77与arr[0],arr[1],arr[2].... 比较，找到比他大的那个数？
		int index = arr.length;//假设score放到数组的index位置
		for(int i=0;i<arr.length;i++){
			if(score<arr[i]){
				//记录这个位置
				index = i;
				break;
			}
		} 
		if(index==arr.length){//表明 score比数组的任意一个数都大
			//arr[0]=arr[1]  arr[1]=arr[2] arr[2]=arr[3] arr[3]=arr[4]
			for(int i=0;i<arr.length-1;i++){
				arr[i]=arr[i+1];
			}
			//将score放到数组的index位置
			arr[index-1] = score;
		}else if(index==0){//score比所有数都小
			//直接放到arr[0]
			arr[index]=score;

		}else{
			//1.arr[0]=arr[1] arr[1]=arr[2] ... arr[index-2]=arr[index-1]
			for(int i=0;i<=index-2;i++){
				arr[i]=arr[i+1];
			}
			//2.将score插入到index-1位置
			arr[index-1]=score;
		}
		//输出数组的值
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"\t");
		}
	}
}
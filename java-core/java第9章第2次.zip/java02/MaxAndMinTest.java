/*数组最大小值，
if(arr[1]>max){
	max = arr[1];
}
if(arr[2]>max){
	max = arr[2];
}
if(arr[3]>max){
	max = arr[3];
}
*/
public class MaxAndMinTest{
	public static void main(String[] args){
		int[] arr = {9,6,5,8,7};
		//假设法
		int max = arr[0];

		int min = arr[0];
		for(int i=1;i<arr.length;i++){
			if(arr[i]>max){
				max = arr[i];
			}
			if(arr[i]<min){
				min = arr[i];
			}	
		}
		System.out.print("数组最大值为："+max+"\t最小值为："+min);



	}
}
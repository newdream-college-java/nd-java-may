/*
定义一个数组保存，古代四大美人 然后输出四大美人的名字

*/
public class ArrDemo01{
	public static void main(String[] args){
		String[] arrStr;
		arrStr = new String[4];
		arrStr[0] = "王昭君";
		arrStr[1] = "西施";
		arrStr[2] = "杨玉环";
		arrStr[3] = "貂蝉";

		for(int i=0;i<4;i++){
			System.out.print(arrStr[i]+"\t");
		}


	}
}
/*
练习：定义数组保存1~10中所有的偶数，并求和输出，随机生成一个1~100之间的整数
判断这个随机数是不是在这个数组中。
*/
import java.util.*;
public class ArrTest04{
	public static void main(String[] args){
		Random rd = new Random();
		//1.求出1~10中有多少个偶数
		int count = 0;
		for(int i=1;i<=10;i++){
			if(i%2==0){
				count++;
			}
		}
		//2.定义数组 ----不知道定义多大  count=5
		int[] arr = new int[count];
		//3.将1~10所有偶数挑出来，保存到arr数组
		int sum = 0;
		int j = 0;//j表示arr数组的下标 从0开始
		for(int i=1;i<=10;i++){
			if(i%2==0){
				arr[j] = i;
				sum+=arr[j];
				System.out.print(arr[j]+"\t");
				j++;
			}

		}
		System.out.println("\n所有偶数和为："+sum);
		//4.随机产生一个整数
		boolean flag = false;
		//1~100
		int number = rd.nextInt(100)+1;
		for(int i=0;i<arr.length;i++){
			if(number==arr[i]){
				System.out.println(number+"在数组的下标为"+i+"的位置");
				flag = true;
				break;
			}
		}
		if(!flag){
			System.out.println(number+"不在数组中！！！");
		}


	}
}
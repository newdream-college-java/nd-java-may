/*
将数组int[] arr = {9,6,5,8,7}; 中所有的偶数赋值到另外一个数组brr,要求
brr数字大小不能大也不能小。
int[] arr = {9,6,5,8,7};
brr[0]=arr[1]
brr[1] = arr[3]

*/
public class CopyTest{
	public static void main(String[] args){
		int[] arr = {9,6,5,8,7};
		int count =0;
		//1.求偶数的偶数
		for(int i=0;i<arr.length;i++){
			if(arr[i]%2==0){
				count++;
			}
		}
		//2.定义brr数组
		int[] brr = new int[count];
		//3.从arr数组中挑出偶数放到brr数组中
		int j =0;//j表示brr数组的下标
		for(int i=0;i<arr.length;i++){
			if(arr[i]%2==0){
				brr[j] = arr[i];
				j++;
			}
		}
		//4.显示brr数组
		for(int i=0;i<brr.length;i++){
			System.out.print(brr[i]+"\t");
		}





	}
}
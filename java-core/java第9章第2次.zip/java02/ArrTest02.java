/*Java考试结束后，老师给张浩分配了一项任务，让他计算全班（30人）
的平均分*/
import java.util.*;
public class ArrTest02{
	public static void main(String[] args){
		Scanner input =new Scanner(System.in);
		//提示
		System.out.println("请输入10个同学的成绩：");
		int[] arr ;
		arr = new int[10];
		int sum = 0;
		/*
		arr[0] = input.nextInt();
		arr[1] = input.nextInt();
		arr[2] = input.nextInt();
		....
		arr[9] = input.nextInt();
		*/
		//等价于上的面多句代码
		for(int i=0;i<arr.length;i++){
			arr[i] = input.nextInt();
			sum+=arr[i];
		}
		//计算平局分
		System.out.println("10个同学的平局分为："+sum/10.0);
		
	}
}
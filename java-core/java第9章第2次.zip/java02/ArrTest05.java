/*
循环录入5位学员成绩，进行升序排列后输出结果
*/
import java.util.*;
import java.util.Arrays;
public class ArrTest05{
	public static void main(String[] args){
		Scanner input =new Scanner(System.in);
		int[] arr = new int[5];
		//提示
		System.out.println("请输入5个同学的成绩：");
		for(int i=0;i<arr.length;i++){
			arr[i]=input.nextInt();
		}
		//升序方式一：Arrays.sort(arr); 自动对数组进行升序排序
		Arrays.sort(arr);//缺点：只能升序
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"\t");
		}


	}
}